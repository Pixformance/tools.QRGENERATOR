﻿using System.Windows.Forms;

namespace TestWizard
{
	public partial class MyStepWizard : Form
	{
		public MyStepWizard()
		{
			InitializeComponent();
		}
	}
}
